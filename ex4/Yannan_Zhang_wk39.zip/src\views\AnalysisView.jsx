import React from "react"

const AnalysisView = () => {
    return (
        <div>
            <h1>Analysis Page</h1>
            <p>This is the analysis page</p>
        </div>
    )
}

export default AnalysisView