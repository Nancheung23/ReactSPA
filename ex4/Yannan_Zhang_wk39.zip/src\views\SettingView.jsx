import React from "react"

const SettingView = () => {
    return (
        <div>
            <h1>Setting Page</h1>
            <p>This is the Setting page</p>
        </div>
    )
}


export default SettingView